package com.cg.uas.dto;



import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="Programs_Scheduled")
public class Programs_Scheduled

{

	@Id
	@Column(name="scheduled_Program_Id",length=5)
	private String scheduled_Program_Id ;
	
	@Column(name="programName",length=15)
	private String programName ;
	
	@Column(name="city",length=10)
	private String city  ;
	
	@Column(name="pincode")
	private int pincode	 ;
	
	@Column(name="start_Date")
	private Date start_Date  ;
	
	@Column(name="end_Date")
	private Date end_Date  ;
	
	@Column(name="sessions_Per_Week")
	private int sessions_Per_Week ;
	
	
	@Override
	public String toString() {
		return "Programs_Scheduled [scheduled_Program_Id="
				+ scheduled_Program_Id + ", programName=" + programName
				+ ", city=" + city + ", pincode=" + pincode + ", start_Date="
				+ start_Date + ", end_Date=" + end_Date
				+ ", sessions_Per_Week=" + sessions_Per_Week + "]";
	}
	
	public String toString2() {
		return  scheduled_Program_Id + "," + programName + "," + city + "," + pincode + "," + start_Date + "," + end_Date + "," + sessions_Per_Week+"\n";
	}


	public String getScheduled_Program_Id() {
		return scheduled_Program_Id;
	}


	public void setScheduled_Program_Id(String scheduled_Program_Id) {
		this.scheduled_Program_Id = scheduled_Program_Id;
	}


	public String getProgramName() {
		return programName;
	}


	public void setProgramName(String programName) {
		this.programName = programName;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public int getPincode() {
		return pincode;
	}


	public void setPincode(int pincode) {
		this.pincode = pincode;
	}


	public Date getStart_Date() {
		return start_Date;
	}


	public void setStart_Date(Date date) {
		this.start_Date = date;
	}


	public Date getEnd_Date() {
		return end_Date;
	}


	public void setEnd_Date(Date dob) {
		this.end_Date = dob;
	}


	public int getSessions_Per_Week() {
		return sessions_Per_Week;
	}


	public void setSessions_Per_Week(int sessions_Per_Week) {
		this.sessions_Per_Week = sessions_Per_Week;
	}
	
	
	
}
