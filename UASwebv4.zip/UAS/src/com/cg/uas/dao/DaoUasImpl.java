package com.cg.uas.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.uas.dto.Application;
import com.cg.uas.dto.Programs_Offered;
import com.cg.uas.dto.Programs_Scheduled;
import com.cg.uas.dto.Users;
import com.cg.uas.exception.UasException;

@Repository
@Transactional
public class DaoUasImpl implements IDaoUas {

	@PersistenceContext
	EntityManager entityManager;
	private Logger classLogger;


	@Override
	public List<Programs_Scheduled> allPrograms() throws UasException {

		try {

			TypedQuery<Programs_Scheduled> qry = entityManager.createQuery(
					"from Programs_Scheduled", Programs_Scheduled.class);

			List<Programs_Scheduled> list = qry.getResultList();
			return list;

		} catch (Exception exp) {
			
			throw new UasException("Failed to get Programs Schedule!");
		}

	}

	@Override
	public int apply(Application application) throws UasException {
		int appId = -1;
		try {

			int result1 =0;
			System.out.println(application.toString());
			Programs_Scheduled of=entityManager.find(Programs_Scheduled.class,application.getScheduled_Program_Id());
			if(of!=null)
			{		
			entityManager.persist(application);
			System.out.println("abfqkf");
			Query qry2 = entityManager
					.createQuery("select application_Id FROM Application where full_Name=:name and email_Id=:mail");
			qry2.setParameter("name",application.getFull_Name());
			qry2.setParameter("mail",application.getEmail_Id());
			System.out.println("3656");
	
			
			System.out.println("hereewwewe");

			 result1 = (int) qry2.getSingleResult();
			 System.out.println("987");
			}
				if (result1 >= 1000) {
					appId = result1;
					
				}
				else {
					appId = -1;
					
				}
			 
		} catch (Exception msg) {
			
			throw new UasException("Failed to register application. Duplicate application");
		}

		return appId;
	}

	@Override
	public String status(int application_Id) throws UasException {
		String status = null;
		try {

			TypedQuery<String> qry = entityManager.createQuery(
					"SELECT status FROM Application WHERE application_id=:id",
					String.class);
			qry.setParameter("id", application_Id);
			status = qry.getSingleResult();

			
			}
		 catch (Exception exp) {
			
			throw new UasException("Failed to get Application status");
		}
		return status;
	}

	@Override
	public boolean macLogin(String userName, String Password)
			throws UasException {
		boolean valid = false;

		int result=0;
		
		try {
			
			Query qry=entityManager.createQuery("from Users where login_Id=:id and password=:pass");
			
			
			qry.setParameter("id", userName);
			qry.setParameter("pass", Password);
			List<Users> user= qry.getResultList();
			for(Users u:user)
			{	
				if(u.getLogin_id().equals(userName) && u.getPassword().equals(Password)&& u.getRole().equals("mac"))	
					result=1;
			}
			
			
         
            
            
			if (result>0) {
				valid = true;
			}

		} catch (Exception exp) {
			classLogger.error(exp);
			throw new UasException("Failed to authenticate ");}
		
		return valid;
	}

	@Override
	public boolean adminLogin(String userName, String Password)
			throws UasException {
		boolean valid = false;

		try {

	Query qry=entityManager.createQuery("from Users where login_Id=:id and password=:pass");
			
			
			qry.setParameter("id", userName);
			qry.setParameter("pass", Password);
			List<Users> user= qry.getResultList();
			int result=0;
			for(Users u:user)
			{	
				if(u.getLogin_id().equals(userName) && u.getPassword().equals(Password)&& u.getRole().equals("admin"))	
					result=1;
			}
			
			if (result >0) {
				valid = true;
	
			}
		} catch (Exception exp) {
			classLogger.error(exp);
			throw new UasException("Failed to authenticate ");
		}
		return valid;
	}

	@Override
	public List<Application> allApplications(String programName)
			throws UasException {

		List<Application> applicationsList=new ArrayList<Application>();
		try {
			System.out.println("1");
			Query qry1=entityManager.createQuery("select scheduled_Program_Id from Programs_Scheduled where programName=?");
			System.out.println("qwertymk");
			qry1.setParameter(1, programName);
			System.out.println("qwertyjijk");
			List<String> sch=qry1.getResultList();
			System.out.println("qwertysjvfk");
			TypedQuery<Application> qry=entityManager.createQuery("from Application",Application.class);
			List<Application> list = qry.getResultList();
			System.out.println("qwerty");
			for(String a:sch)
			{System.out.println(a.toString());
				for(Application s:list)
				{
					System.out.println(s.toString());
					if(a.equals(s.getScheduled_Program_Id()))
				applicationsList.add(s);	
				}
			}
			

		} catch (Exception exp) {
			
			System.out.println("here");
			System.out.println(exp);
			classLogger.error(exp);
			throw new UasException("Failed to get applications!");
		}

		return applicationsList;

	}

	@Override
	public boolean acceptApplication(int application_Id, LocalDate iDate)
			throws UasException {
		boolean valid = false;

		try {
			
			Query qry= entityManager.createQuery("UPDATE Application SET Status='accepted',Date_Of_Interview=? WHERE application_Id=?");
		

			qry.setParameter(1, java.sql.Date.valueOf(iDate));
			qry.setParameter(2, application_Id);

			int result = qry.executeUpdate();

			if (result > 0) {
				valid = true;
			} else {
				valid = false;
				
			}
		} catch (Exception exp) {
			classLogger.error(exp);
			throw new UasException("Failed to update accept status ");
		}
		return valid;
	}

	@Override
	public boolean rejectApplication(int application_Id) throws UasException {
		boolean valid = false;

		try {
			
			
			Query qry=entityManager.createQuery("UPDATE Application SET Status='rejected' WHERE application_Id=?");
			

			qry.setParameter(1, application_Id);

			int result = qry.executeUpdate();
			if (result > 0) {
				valid = true;
			} else {
				valid = false;
		
			}

		} catch (Exception exp) {
			classLogger.error(exp);
			throw new UasException("Failed to update reject status ");
		}
		return valid;
	}

	@Override
	public boolean confirmApplication(int application_Id) throws UasException {
		boolean valid = false;

		try 
		
		{
			
			Query qry=entityManager.createQuery("UPDATE Application SET Status='confirmed' WHERE application_Id=?");
			

			qry.setParameter(1, application_Id);

			int result = qry.executeUpdate();

			if (result > 0) {
				valid = true;
			} else {
				valid = false;
				System.out.println("No applicant found with entered Id");
			}
		} catch (Exception exp) {
			classLogger.error(exp);
			throw new UasException("Failed to update confirm status ");
		}
		return valid;
	}


	@Override
	public boolean updProgramOffered(Programs_Offered program_offered,
			String ProgramName) throws UasException {

		boolean valid = false;

		try {

			Query qry = entityManager
					.createQuery("UPDATE Programs_offered SET ProgramName=?,description=?,applicant_eligibility=?,duration=?,degree_certificate_offered=? WHERE ProgramName=?");

			qry.setParameter(1, program_offered.getProgramName());
			qry.setParameter(2, program_offered.getDescription());
			qry.setParameter(3, program_offered.getApplicant_Eligibility());
			qry.setParameter(4, program_offered.getDuration());
			qry.setParameter(5, program_offered.getDegree_Certificate_Offered());
			qry.setParameter(6, ProgramName);

			int result = qry.executeUpdate();
			if (result > 0) {
				valid = true;
			} else {
				System.out.println("Invalid ProgramName Entered to update");
				valid = false;
			}
		} catch (Exception msg) {
			classLogger.error(msg);
			throw new UasException("Failed to Update Programs offered");
		}

		return valid;
	}

	@Override
	public boolean addProgramOffered(Programs_Offered program_offered)
			throws UasException {
		boolean valid = false;

		try {
			entityManager.persist(program_offered);
			valid = true;
		} catch (PersistenceException msg) {
			classLogger.error(msg);
			throw new UasException("Failed to Add Programs offered");
		}
		return valid;
	}

	@Override
	public boolean delProgramOffered(String programName) throws UasException {

		boolean valid = false;
		try {
              
              Programs_Offered off=entityManager.find(Programs_Offered.class,
  					programName);
              System.out.println(off.toString());
  			if(off!=null)	
		
  				{entityManager.remove(entityManager.find(Programs_Offered.class,
  					programName));
  			valid=true;
		}
  			
  				
		} catch (Exception exp) {
			
			
			throw new UasException("Program not found in database");
		}

		return valid;
	}

	@Override
	public boolean updProgramScheduled(Programs_Scheduled program_Scheduled,
			String scheduled_Program_Id) throws UasException {
		// TODO Auto-generated method stub
		boolean valid = false;

		try {

			Query qry = entityManager
					.createQuery("UPDATE Programs_Scheduled SET Scheduled_program_id=?,ProgramName=?,City=?,Pincode=?,start_date=?,end_date=?,sessions_per_week=? WHERE Scheduled_program_id=?");

			qry.setParameter(1, program_Scheduled.getScheduled_Program_Id());
			qry.setParameter(2, program_Scheduled.getProgramName());
			qry.setParameter(3, program_Scheduled.getCity());
			qry.setParameter(4, program_Scheduled.getPincode());
			qry.setParameter(5, program_Scheduled.getStart_Date().toString());
			qry.setParameter(6, program_Scheduled.getEnd_Date().toString());
			qry.setParameter(7, program_Scheduled.getSessions_Per_Week());
			qry.setParameter(8, scheduled_Program_Id);

			int result = qry.executeUpdate();
			if (result > 0) {
				valid = true;
			} else {
				valid = false;
			}
		} catch (Exception msg) {
			classLogger.error(msg);
			throw new UasException("Failed to update Programs scheduled");
		}

		return valid;
	}

	@Override
	public boolean addProgramScheduled(Programs_Scheduled program_Scheduled)
			throws UasException {
		// TODO Auto-generated method stub
		boolean valid = false;
		Programs_Offered of=entityManager.find(Programs_Offered.class, program_Scheduled.getProgramName());
		
		
		try {
			if(of!=null)
			{
			entityManager.persist(program_Scheduled);

			valid = true;
			}

		} catch (Exception msg) {
			
			throw new UasException("Failed to add Programs scheduled");
		}
		return valid;
	}

	@Override
	public boolean delProgramScheduled(String scheduled_Program_Id)
			throws UasException {
		boolean valid = false;
		try {
			System.out.println("Hello dao1");
			Programs_Scheduled of=entityManager.find(Programs_Scheduled.class,
					scheduled_Program_Id);
			if(of!=null)
			{
			entityManager.remove(entityManager.find(Programs_Scheduled.class,
					scheduled_Program_Id));
			System.out.println("Hello dao 2");
			valid = true;
			}
			
		} catch (Exception exp) {
		
			throw new UasException("Failed to delete programs scheduled");
		}

		return valid;
	}

	@Override
	public List<Application> viewApplicants() throws UasException {

		List<Application> applicantsList = new ArrayList<>();
		try {

			TypedQuery<Application> qry = entityManager.createQuery(
					"FROM Application WHERE status!='applied'",
					Application.class);
			applicantsList = qry.getResultList();

		} catch (Exception exp) {
			classLogger.error(exp);
			throw new UasException("Failed to get Applicants List!");
		}

		return applicantsList;

	}

	@Override
	public List<Programs_Scheduled> viewPrograms(LocalDate startDate,
			LocalDate endDate) throws UasException {

		List<Programs_Scheduled> programsList = new ArrayList<>();

		try {

			TypedQuery<Programs_Scheduled> qry = entityManager
					.createQuery(
							"FROM Programs_Scheduled WHERE Start_date>? AND End_date<?",
							Programs_Scheduled.class);
			qry.setParameter(1, startDate);
			qry.setParameter(2, endDate);
			programsList = qry.getResultList();

		} catch (Exception msg) {
			classLogger.error(msg);
			throw new UasException("Failed to get program lists");
		}

		return programsList;
	}

}
